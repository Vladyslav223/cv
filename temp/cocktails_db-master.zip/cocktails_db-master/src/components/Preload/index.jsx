import React from 'react';
import './index.scss';


const PreLoad = () => (
  <div className="lds-ellipsis">
    <div />
    <div />
    <div />
    <div />
  </div>
);

export default PreLoad;
