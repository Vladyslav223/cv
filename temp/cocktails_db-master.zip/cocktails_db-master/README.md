This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

Test task Cocktails_DB done using React, Redux, Redux-saga, Redux-form, Material_UI, Axios, useEffect hook and others.